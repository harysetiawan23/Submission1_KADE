package com.example.harry.submission_2kade

import android.os.Bundle
import android.support.design.widget.Snackbar
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem
import com.example.harry.submission_2kade.Api.Api
import com.example.harry.submission_2kade.Api.EndPoint
import com.example.harry.submission_2kade.Model.EventsItem
import com.example.harry.submission_2kade.Model.TeamDetail
import com.squareup.picasso.Picasso

import kotlinx.android.synthetic.main.activity_match_detail.*
import kotlinx.android.synthetic.main.content_match_detail.*
import org.jetbrains.anko.toast
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MatchDetail : AppCompatActivity() {

    lateinit var matchDetail: EventsItem

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_match_detail)
        toolbar.title = "Match Detail"
        setSupportActionBar(toolbar)

        supportActionBar!!.setDisplayHomeAsUpEnabled(true)

        matchDetail = intent.getSerializableExtra("match") as EventsItem

        if (matchDetail.intHomeScore == null && matchDetail.intAwayScore == null) {
            home_score.text = "?"
            away_score.text = "?"
        } else {
            home_score.text = matchDetail.intHomeScore.toString()
            away_score.text = matchDetail.intAwayScore.toString()
        }

        home_team.text = matchDetail.strHomeTeam
        home_crest.let {
            Picasso.get().load(matchDetail!!.strHomeTeam.toString()).into(home_crest)
        }


        away_team.text = matchDetail.strAwayTeam
        away_crest.let {
            Picasso.get().load(matchDetail!!.strAwayTeam.toString()).into(away_crest)
        }

        match_date.text = matchDetail.dateEvent
        getHomeTeamBedge(matchDetail.idHomeTeam.toString())
        getAwayTeamBedge(matchDetail.idAwayTeam.toString())

        home_goal_scorer.text = matchDetail.strHomeGoalDetails.toString()
        away_goal_scorer.text = matchDetail.strAwayGoalDetails.toString()

        home_forward.text = matchDetail.strHomeLineupForward.toString()
        away_forward.text = matchDetail.strAwayLineupForward.toString()

        home_midfilder.text = matchDetail.strHomeLineupMidfield.toString()
        away_midfilder.text = matchDetail.strAwayLineupMidfield.toString()

        home_defender.text = matchDetail.strHomeLineupDefense.toString()
        away_defender.text = matchDetail.strAwayLineupDefense.toString()

        home_goalkeeper.text = matchDetail.strHomeLineupGoalkeeper.toString()
        away_goalkeeper.text = matchDetail.strAwayLineupGoalkeeper.toString()

        home_subs.text = matchDetail.strHomeLineupSubstitutes.toString()
        away_subs.text = matchDetail.strAwayLineupSubstitutes.toString()

    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when (item!!.itemId) {
            android.R.id.home -> finish()
        }

        return super.onOptionsItemSelected(item)
    }


    fun getHomeTeamBedge(teamID: String) {
        val api: EndPoint = Api.create()
        val callTeamDetail: Call<TeamDetail> = api.getTeamDetail(teamID)

        callTeamDetail.enqueue(object : Callback<TeamDetail> {
            override fun onFailure(call: Call<TeamDetail>, t: Throwable) {
                toast("Home Logo Get Failed")
            }

            override fun onResponse(call: Call<TeamDetail>, response: Response<TeamDetail>) {
                home_crest.let {
                    Picasso.get().load(response!!.body()!!.teams!![0]!!.strTeamBadge).into(home_crest)
                }
                toast("Home Logo Get Success")
            }

        })

    }


    fun getAwayTeamBedge(teamID: String) {
        val api: EndPoint = Api.create()
        val callTeamDetail: Call<TeamDetail> = api.getTeamDetail(teamID)

        callTeamDetail.enqueue(object : Callback<TeamDetail> {
            override fun onFailure(call: Call<TeamDetail>, t: Throwable) {
                toast("Away Logo Get Success")
            }

            override fun onResponse(call: Call<TeamDetail>, response: Response<TeamDetail>) {
                home_crest.let {
                    Picasso.get().load(response!!.body()!!.teams!![0]!!.strTeamBadge).into(away_crest)
                }
                toast("Away Logo Get Success")
            }

        })

    }


}
